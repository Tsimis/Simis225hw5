public class OrderQueue {
    private LinkedQueue<CustomerOrder> orderQueue;
    private int stock;

    public OrderQueue(){
        orderQueue=new LinkedQueue<>();
        stock=0;
    }

    public OrderQueue( int stock){
        orderQueue = new LinkedQueue<>();
        this.stock=stock;
    }

    public void addNewOrder(String name, String date, int quantity){
        CustomerOrder order = new CustomerOrder(name,date,quantity);
        orderQueue.enqueue(order);
    }

    public void addStock(int additionalStock){
        stock = stock + additionalStock;
    }

    public void frontFulfilled(){
        if ((orderQueue.isEmpty()==false)&&(stock>0)){
            CustomerOrder order = orderQueue.getFront();
            order.shipProduct();
            if (order.getQuantity()==0){
                orderQueue.dequeue();
            }
            stock=stock-1;
        }
    }

    public void sellStock(){
        while ((orderQueue.isEmpty()==false)&&(stock>0)){
            frontFulfilled();
        }
    }

    public String toString(){
        return String.valueOf(orderQueue.getFront().getQuantity());
    }
}
