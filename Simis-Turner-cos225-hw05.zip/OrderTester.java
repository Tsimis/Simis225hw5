public class OrderTester {
    public static void main(String[] args){
        OrderQueue orderQueue = new OrderQueue(14);
        orderQueue.addNewOrder("Chris","4/5/2022",5);
        orderQueue.addNewOrder("Sam","4/5/2022",5);
        orderQueue.addNewOrder("Issac","4/5/2022",8);
        System.out.println(orderQueue);
        orderQueue.sellStock();
        System.out.println(orderQueue);
        orderQueue.addStock(10);
        orderQueue.addNewOrder("Billy","4/5/2022",3);
        orderQueue.addNewOrder("Tommy","4/5/2022",3);
        orderQueue.addNewOrder("Ted","4/5/2022",5);
        orderQueue.sellStock();
        System.out.println(orderQueue);
    }
}
